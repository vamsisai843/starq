
This is the hello world application which has been created in python. </br>Here we have used docker file as well , which is used to create image.
This repositiry is basically created to have the demonstration of <a href="https://www.youtube.com/watch?v=7qyWriiUenw" target="_blank">"How to deploy docker image to Azure App Services."
  </a>
https://www.youtube.com/watch?v=7qyWriiUenw&t

</br>
I have a video which will help you to deploy this to Azure App Services.
</br>
Here we have flask server which is running on 80 port.
